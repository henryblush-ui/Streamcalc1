# StreamCalc
Offline-first Android streamer earnings calculator.

## Features
- Editable revenue sources and per-source platform/payment fees
- Twitch-style, YouTube-style, Kick-style and mixed presets
- Custom currency code/symbol and tax rate
- Gross, fees, tax, net and net-per-hour calculations
- Dark/light theme
- Local persistence via WebView storage
- Export/import settings as JSON
- No account, server or internet connection required

## Build
Open this folder in Android Studio and build `app` → `assembleDebug`.
A GitHub Actions workflow is included and builds `app-debug.apk` automatically when the project is pushed to GitHub.
