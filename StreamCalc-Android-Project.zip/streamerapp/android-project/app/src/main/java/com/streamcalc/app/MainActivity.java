package com.streamcalc.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
        WebView w=new WebView(this); setContentView(w); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setBuiltInZoomControls(false); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/index.html"); }
    @Override public void onBackPressed(){ WebView w=(WebView)findViewById(android.R.id.content); if(w!=null) super.onBackPressed(); else super.onBackPressed(); }
}
